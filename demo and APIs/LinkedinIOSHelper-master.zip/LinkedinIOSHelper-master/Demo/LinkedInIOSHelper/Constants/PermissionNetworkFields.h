//
//  PermissionNetworkFields.h
//  Demo
//
//  Created by Ahmet Kazım Günay on 02/04/15.
//  Copyright (c) 2015 Ahmet Kazım Günay. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PermissionNetworkFields : NSObject

/*!
 * @brief Members connections
 */
extern NSString * const connections;

@end
