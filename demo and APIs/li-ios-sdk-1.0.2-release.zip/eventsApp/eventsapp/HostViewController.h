#import <QuartzCore/QuartzCore.h>

#import "ViewPagerController.h"

@interface HostViewController : ViewPagerController

@end
