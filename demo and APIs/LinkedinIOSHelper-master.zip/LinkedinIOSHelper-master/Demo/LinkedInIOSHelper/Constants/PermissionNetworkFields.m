//
//  PermissionNetworkFields.m
//  Demo
//
//  Created by Ahmet Kazım Günay on 02/04/15.
//  Copyright (c) 2015 Ahmet Kazım Günay. All rights reserved.
//

#import "PermissionNetworkFields.h"

@implementation PermissionNetworkFields

NSString * const connections = @"connections";

@end
