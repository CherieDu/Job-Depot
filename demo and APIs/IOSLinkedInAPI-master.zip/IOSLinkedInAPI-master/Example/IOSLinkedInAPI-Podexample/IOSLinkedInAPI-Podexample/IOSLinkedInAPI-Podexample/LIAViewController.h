//
//  LIAViewController.h
//  IOSLinkedInAPI-Podexample
//
//  Created by Jacob von Eyben on 16/12/13.
//  Copyright (c) 2013 Eyben Consult ApS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LIAViewController : UIViewController

@end
