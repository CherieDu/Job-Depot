//
//  DeepLinkViewController.h
//  sampleapp
//
//  Created by Fred Cheng on 4/1/15.
//  Copyright (c) 2015 linkedin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DeepLinkViewController : UIViewController

@end
