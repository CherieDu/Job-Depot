//
//  PermissionEmailFields.m
//  Demo
//
//  Created by Ahmet Kazım Günay on 02/04/15.
//  Copyright (c) 2015 Ahmet Kazım Günay. All rights reserved.
//

#import "PermissionEmailFields.h"

@implementation PermissionEmailFields

NSString * const email_address  = @"email-address";

@end
